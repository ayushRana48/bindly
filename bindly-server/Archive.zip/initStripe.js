const stripe = require('stripe')('sk_test_51PVKUSBgzlfK4h49tBChOo2Da6guBHjIHM0uIsmM6VRS2osV5toT0kDcNoqNyZNRcwJlMPmvuGeXjKW61EP8pirO00PseMscAg');

module.exports= { stripe };
