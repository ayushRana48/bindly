const { supabase } = require('../initSupabase');

const uploadFile = async (fileData, bucketName, fileName, timestamp, newTimeStamp) => {
    let fileUrl = "";
    let fileExt = "jpg"; // Default to jpg, but we will detect the type
    let contentType = "image/jpeg"; // Default content type

    try {
        if (fileData) {
            // Extract the MIME type from the Base64 data
            const match = fileData.match(/^data:([^;]+);base64,/);
            if (match) {
                const mimeType = match[1];
                fileExt = mimeType.split('/')[1];
                contentType = mimeType;

                fileData = fileData.replace(/^data:[^;]+;base64,/, "");
            }

            const buffer = Buffer.from(fileData, 'base64');

            if (timestamp) {
                const oldFileName = `${fileName}-${timestamp.substring(0, timestamp.length - 6)}Z.${fileExt}`;

                const { error: deleteError } = await supabase.storage
                    .from(bucketName)
                    .remove([oldFileName]);

                if (deleteError && deleteError.message !== 'The resource was not found') {
                    console.error('Error deleting old file:', deleteError);
                    return { fileUrl: null, error: deleteError };
                }
            }

            const { data: fileData, error: fileError } = await supabase.storage
                .from(bucketName)
                .upload(`${fileName}-${newTimeStamp}.${fileExt}`, buffer, {
                    contentType: contentType,
                    upsert: true,
                });

            if (fileError) {
                console.error('Error uploading file:', fileError);
                return { fileUrl: null, error: fileError };
            } else {
                fileUrl = `https://lxnzgnvhkrgxpfsokwos.supabase.co/storage/v1/object/public/${bucketName}/${fileName}-${newTimeStamp}.${fileExt}`;
            }
        } else {
            if (timestamp) {
                const oldFileName = `${fileName}-${timestamp}.${fileExt}`;

                const { error: deleteError } = await supabase.storage
                    .from(bucketName)
                    .remove([oldFileName]);

                if (deleteError && deleteError.message !== 'The resource was not found') {
                    console.error('Error deleting old file:', deleteError);
                    return { fileUrl: null, error: deleteError };
                }
            }
        }
    } catch (error) {
        console.error(error);
        return { fileUrl: null, error };
    }

    return { fileUrl, error: null };
};

module.exports = { uploadFile };
